<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Termék leadás</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="public/css/style.css">
</head>
<body>
<?php include 'header.php'; ?>
    <div class="container my-4">
        <header>
            <h1>Termék felvételi lap</h1>
         
        </header>
        <main>
            <form method="POST">
                <div class="mb-3">
                    <label>Termék - Szériaszám</label>
                    <input type="text" name="szeriaszam" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>Termék - Gyártó</label>
                    <input type="text" name="gyarto" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>Termék - Típus</label>
                    <input type="text" name="tipus" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>Megrendelő - Név</label>
                    <input type="text" name="nev" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>Megrendelő - Telefon</label>
                    <input type="text" name="telefon" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>Megrendelő - Email</label>
                    <input type="email" name="email" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary">Mentés</button>
            </form>
        </main>
<?php
include_once('footer.php');
?>
    </div>
</body>
</html>

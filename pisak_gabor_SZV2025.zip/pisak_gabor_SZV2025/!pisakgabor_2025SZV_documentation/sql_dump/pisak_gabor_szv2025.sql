-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2025. Júl 31. 18:14
-- Kiszolgáló verziója: 10.4.32-MariaDB
-- PHP verzió: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `pisak_gabor_szv2025`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `kapcsolattartok`
--

CREATE TABLE `kapcsolattartok` (
  `id` int(11) NOT NULL,
  `termek_id` int(11) NOT NULL,
  `nev` varchar(100) NOT NULL,
  `telefon` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci;

--
-- A tábla adatainak kiíratása `kapcsolattartok`
--

INSERT INTO `kapcsolattartok` (`id`, `termek_id`, `nev`, `telefon`, `email`) VALUES
(1, 1, 'Pisák Gábor', '06304060169', 'pisakgabor@gmail.com'),
(2, 2, 'Kiss Ödön', '06304060169', 'info@rixweb.hu'),
(3, 3, 'Pisák Patrik', '0614526161', 'apafant@icloud.com');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `termekek`
--

CREATE TABLE `termekek` (
  `id` int(11) NOT NULL,
  `szeriaszam` varchar(100) NOT NULL,
  `gyarto` varchar(100) NOT NULL,
  `tipus` varchar(100) NOT NULL,
  `leadas_datum` date NOT NULL,
  `statusz` enum('Beérkezett','Hibafeltárás','Alkatrész beszerzés alatt','Javítás','Kész') NOT NULL DEFAULT 'Beérkezett',
  `statusz_valtozas` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_hungarian_ci;

--
-- A tábla adatainak kiíratása `termekek`
--

INSERT INTO `termekek` (`id`, `szeriaszam`, `gyarto`, `tipus`, `leadas_datum`, `statusz`, `statusz_valtozas`) VALUES
(1, 'MF2025_65_WHITE_09', 'Delonghi', 'Magnifica White', '2025-07-31', 'Kész', '2025-07-31 18:11:08'),
(2, 'TF2020UB101', 'Tefal', 'Ultra Blend', '2025-07-31', 'Hibafeltárás', '2025-07-31 18:14:27'),
(3, 'RP_222_RiX', 'EuroREP', 'Klimatica2000', '2025-07-31', 'Javítás', '2025-07-31 18:14:21');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `kapcsolattartok`
--
ALTER TABLE `kapcsolattartok`
  ADD PRIMARY KEY (`id`),
  ADD KEY `termek_id` (`termek_id`);

--
-- A tábla indexei `termekek`
--
ALTER TABLE `termekek`
  ADD PRIMARY KEY (`id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `kapcsolattartok`
--
ALTER TABLE `kapcsolattartok`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT a táblához `termekek`
--
ALTER TABLE `termekek`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `kapcsolattartok`
--
ALTER TABLE `kapcsolattartok`
  ADD CONSTRAINT `kapcsolattartok_ibfk_1` FOREIGN KEY (`termek_id`) REFERENCES `termekek` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php include 'header.php'; ?>

<div class="container mt-5">
    <h2 class="mb-4">Leadott javítások lekérdezése</h2>

    <form method="get" action="index.php">
        <input type="hidden" name="page" value="check">
        <div class="mb-3">
            <label for="email" class="form-label">E-mail cím:</label>
            <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($email) ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Keresés</button>
    </form>

    <?php if (!empty($email)): ?>
        <h3 class="mt-5">Találatok az e-mail címre: <?= htmlspecialchars($email) ?></h3>

        <?php if (!empty($services)): ?>
            <table class="table table-bordered mt-3">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Termék</th>
                        <!--<th>Hiba leírása</th>-->
                        <th>Leadás dátuma</th>
                        <th>Státusz</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($services as $service): ?>
                        <tr>
                            <td><?= $service['id'] ?></td>
                            <td><?= htmlspecialchars($service['tipus']) ?></td>
                            <!--<td><?= htmlspecialchars($service['description']) ?></td>-->
                            <td><?= $service['leadas_datum'] ?></td>
                            <td><?= $service['statusz'] ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="text-muted mt-3">Nincs találat az adott e-mail címre.</p>
        <?php endif; ?>
    <?php endif; ?>
</div>

<?php include 'footer.php'; ?>

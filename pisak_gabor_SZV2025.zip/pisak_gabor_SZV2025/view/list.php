<?php
require_once __DIR__ . '/../model/Database.php';
include_once __DIR__ . '/../view/header.php';

$conn = Database::getConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['statusz_modositas'])) {
    $termek_id = (int)$_POST['termek_id'];
    $uj_statusz = $_POST['uj_statusz'];
    $ido = date("Y-m-d H:i:s");

    $stmt = $conn->prepare("UPDATE termekek SET statusz = ?, statusz_valtozas = ? WHERE id = ?");
    $stmt->bind_param("ssi", $uj_statusz, $ido, $termek_id);
    $stmt->execute();
    $stmt->close();
}

$sql = "
    SELECT 
        t.*, 
        k.nev, k.telefon, k.email 
    FROM 
        termekek t
    LEFT JOIN 
        kapcsolattartok k ON t.id = k.termek_id
    ORDER BY 
        t.leadas_datum DESC
";

$items = $conn->query($sql);

$statusz_options = [
    'Beérkezett',
    'Hibafeltárás',
    'Alkatrész beszerzés alatt',
    'Javítás',
    'Kész'
];

// Háttérszínek
$status_colors = [
    'Beérkezett' => 'rgba(0, 0, 255, 0.3)',           // kék
    'Hibafeltárás' => 'rgba(255, 0, 0, 0.3)',          // piros
    'Alkatrész beszerzés alatt' => 'rgba(255, 165, 0, 0.3)', // narancssárga
    'Javítás' => 'rgba(0, 128, 0, 0.3)',               // zöld
    'Kész' => 'rgba(128, 0, 128, 0.3)'                 // lila
];
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Szerviz összesítő</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/public/css/style.css">
</head>
<body>
<div class="container my-4">
    <header class="mb-4">
        <h1>Szerviz összesítő</h1>
        <nav>
            <a href="index.php?page=add" class="btn btn-outline-secondary w-100 my-2">
                <i class="fa-solid fa-square-plus"></i> Termék felvétel
            </a>
        </nav>
    </header>

    <main>
        <table class="table table-bordered  align-middle">
            <thead class="table-dark">
                <tr>
                    <th>Termék</th>
                    
                    <th>Megrendelő</th>
                    <th>Státusz</th>
                    <th>Módosítás</th>
					<th>Időpontok</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $items->fetch_assoc()): ?>
                    <?php
                        $statusz = $row['statusz'];
                        $bg_color = isset($status_colors[$statusz]) ? $status_colors[$statusz] : 'transparent';
                    ?>
                    <tr>
                        <td  style="background: <?= $bg_color ?>;">
                            <strong>SN:</strong> <?= htmlspecialchars($row['szeriaszam']) ?><br>
                            <strong>Gyártó:</strong> <?= htmlspecialchars($row['gyarto']) ?><br>
                            <strong>Típus:</strong> <?= htmlspecialchars($row['tipus']) ?>
                        </td>
                      
                        <td style="background: <?= $bg_color ?>;">
                            <strong>Név:</strong> <?= htmlspecialchars($row['nev']) ?><br>
                            <strong>Telefon:</strong> <?= htmlspecialchars($row['telefon']) ?><br>
                            <strong>Email:</strong> <?= htmlspecialchars($row['email']) ?>
                        </td>
                        <td  style="background: <?= $bg_color ?>;">
                            <form method="POST" class="d-flex justify-content-center align-items-center gap-2"  >
                                <input type="hidden" name="termek_id" value="<?= $row['id'] ?>">
                                <select name="uj_statusz" class="form-select">
                                    <?php foreach ($statusz_options as $status): ?>
                                        <option value="<?= $status ?>" <?= ($statusz === $status) ? 'selected' : '' ?>>
                                            <?= $status ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                        </td>
                        <td  style="background: <?= $bg_color ?>;">
                                <button type="submit" name="statusz_modositas" class="btn btn-sm btn-primary">Mentés</button>
                            </form>
                        </td>
						
						  <td style="background: <?= $bg_color ?>;">
                            <strong>Leadva:</strong> <?= htmlspecialchars($row['leadas_datum']) ?><br>
                            <strong>Módosítva:</strong> <?= htmlspecialchars($row['statusz_valtozas']) ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </main>

    <?php include_once __DIR__ . '/../view/footer.php'; ?>
</div>
</body>
</html>

<?php
require_once '../model/Database.php';

$conn = Database::getConnection();

// Státuszok listája, amit az ENUM-ból vettünk
$statuszok = ['Beérkezett', 'Hibafeltárás', 'Alkatrész beszerzés alatt', 'Javítás', 'Kész'];

// Ha POST érkezett, mentjük a státusz módosítást
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $termek_id = intval($_POST['termek_id']);
    $uj_statusz = $_POST['statusz'];
    if (in_array($uj_statusz, $statuszok)) {
        $stmt = $conn->prepare("UPDATE termekek SET statusz = ?, statusz_valtozas = NOW() WHERE id = ?");
        $stmt->bind_param('si', $uj_statusz, $termek_id);
        $stmt->execute();
        $stmt->close();
        header("Location: mod_statusz.php?msg=success");
        exit;
    } else {
        $error = "Érvénytelen státusz!";
    }
}

// Lekérdezzük a termékeket
$result = $conn->query("SELECT * FROM termekek ORDER BY FIELD(statusz, 'Beérkezett', 'Hibafeltárás', 'Alkatrész beszerzés alatt', 'Javítás', 'Kész'), leadas_datum DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Státusz módosítás</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="public/css/style.css">
    <style>
    /* Ide is beteszem a színezést inline, ha nincs style.css-ben */
    .statusz-beérkezett { background-color: #007bff; color: white; }
    .statusz-hibafeltárás { background-color: #dc3545; color: white; }
    .statusz-alkatrész-beszerzés-alatt { background-color: #fd7e14; color: white; }
    .statusz-javítás { background-color: #6f42c1; color: white; }
    .statusz-kész { background-color: #28a745; color: white; }
    </style>
</head>
<body>
<?php include 'header.php'; ?>
<div class="container my-4">
    <header>
        <h1>Státusz módosítás</h1>
        <nav>
            <a href="index.php">Összesítő</a> |
            <a href="index.php?page=add">Termék leadás</a>
        </nav>
    </header>

    <?php if (!empty($error)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php elseif (isset($_GET['msg']) && $_GET['msg'] === 'success'): ?>
        <div class="alert alert-success">Sikeres mentés!</div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Szériaszám</th>
                <th>Gyártó</th>
                <th>Típus</th>
                <th>Leadás dátuma</th>
                <th>Státusz</th>
                <th>Utolsó változás</th>
                <th>Módosítás</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): 
                $css_class = 'statusz-' . strtolower(str_replace([' ', 'é', 'á', 'í', 'ó', 'ö', 'ő', 'ú', 'ü', 'ű'], ['-', 'e', 'a', 'i', 'o', 'o', 'o', 'u', 'u', 'u'], $row['statusz']));
            ?>
            <tr class="<?= $css_class ?>">
                <td><?= htmlspecialchars($row['szeriaszam']) ?></td>
                <td><?= htmlspecialchars($row['gyarto']) ?></td>
                <td><?= htmlspecialchars($row['tipus']) ?></td>
                <td><?= htmlspecialchars($row['leadas_datum']) ?></td>
                <td><?= htmlspecialchars($row['statusz']) ?></td>
                <td><?= htmlspecialchars($row['statusz_valtozas']) ?></td>
                <td>
                    <form method="post" style="margin:0;">
                        <input type="hidden" name="termek_id" value="<?= $row['id'] ?>">
                        <select name="statusz" class="form-select form-select-sm" onchange="this.form.submit()">
                            <?php foreach ($statuszok as $st): ?>
                                <option value="<?= $st ?>" <?= $st === $row['statusz'] ? 'selected' : '' ?>><?= $st ?></option>
                            <?php endforeach; ?>
                        </select>
                    </form>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
</body>
</html>

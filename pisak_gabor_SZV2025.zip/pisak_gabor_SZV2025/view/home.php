<?php include 'header.php'; ?>

<div class="container text-center mt-5">


    <?php if (isLoggedIn()): ?>
        <?php if (isset($_SESSION['username'])): ?>
		    <h2>Köszöntjük a kisgépszervíz alkalmazotti felületén!</h2>
    <p class="lead mt-4">Helló <b><?=$_SESSION['username']?></b>, <br>kérlek válassz az alábbi lehetőségek közül:</p>
            <div class="d-grid gap-3 col-6 mx-auto mt-4">
                <a href="index.php?page=list" class="btn btn-outline-danger btn-lg">
                    <i class="fa-solid fa-screwdriver-wrench"></i> Javítási lista
                </a>
 
<p><i class="fa-solid fa-info-circle"></i> A javítási listára kattintva kezelhetőek a leadott termékek . A státusz az elvégzett munka alapján változtatható. </p> 
            </div>
        <?php endif; ?>
    <?php else: ?>
	    <h1>Köszöntjük a kisgépszervíz oldalán!</h1>
    <p class="lead mt-4">Kérjük válasszon az alábbi lehetőségek közül:</p>
        <div class="d-grid gap-3 col-6 mx-auto mt-4">
            <a href="index.php?page=add" class="btn btn-primary btn-lg">Javítást adok le</a>
            <a href="index.php?page=check" class="btn btn-outline-secondary btn-lg">Ellenőrzöm a leadott termék státuszát</a>
        </div>
    <?php endif; ?>
</div>

<?php include 'footer.php'; ?>

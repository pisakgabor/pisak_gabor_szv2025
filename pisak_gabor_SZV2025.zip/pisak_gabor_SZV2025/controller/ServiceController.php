<?php
require_once 'model/Database.php';
require_once 'model/ServiceModel.php';

class ServiceController {
    private $model;

    public function __construct() {
        $this->model = new ServiceModel();
    }

public function showHomePage()
{
    include 'view/home.php';
}

    public function showList() {
        $items = $this->model->getActiveServices();
        include 'view/list.php';
    }
	public function showCheckPage()
{
    $email = $_GET['email'] ?? '';
    $services = [];

    if (!empty($email)) {
        require_once 'model/ServiceModel.php';
        $model = new ServiceModel();
        $services = $model->getServicesByEmail($email);
    }

    include 'view/check.php';
}

    public function showAddForm() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->model->addService($_POST);
            header('Location: index.php');
            exit;
        }
        include 'view/add.php';
    }
}

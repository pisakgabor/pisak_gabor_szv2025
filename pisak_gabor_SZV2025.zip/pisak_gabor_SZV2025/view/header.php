<?php require_once __DIR__ . '/../helper/Auth.php'; ?>

<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <title>Kisgép szervíz</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <link href="/public/css/style.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="/index.php">Kisgépszervíz</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    
    <div class="collapse navbar-collapse" id="navbarNav">
      
      <!-- BAL OLDALI NAVIGÁCIÓ -->
<ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="index.php?page=home"><i class="fa-solid fa-home"></i>Kezdőlap</a>
    </li>
  <?php if (isLoggedIn()): ?>
    <!-- Bejelentkezett felhasználóknak -->
    <li class="nav-item">
      <a class="nav-link" href="index.php?page=list"><i class="fa-solid fa-screwdriver-wrench"></i> Javítási lista</a>
    </li>

  <?php else: ?>
    <!-- Nem bejelentkezett felhasználóknak -->
   <li class="nav-item">
      <a class="nav-link" href="index.php?page=add">Termék leadás</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="index.php?page=check">Javításaim megtekintése</a>
    </li>
 
  <?php endif; ?>
</ul>


      <!-- JOBB OLDALI LOGIN/LOGOUT -->
      <ul class="navbar-nav ms-auto" style="padding:3px; border:1px solid grey; border-radius:5px;">
        <?php if (isLoggedIn()): ?>
          <li class="nav-item">
            <a class="nav-link" href="logout.php"><i class="fa-solid fa-user"></i> Kijelentkezés (<?= htmlspecialchars($_SESSION['username']) ?>)</a>
          </li>
        <?php else: ?>
          <li class="nav-item">
            <a class="nav-link" href="login.php"><i class="fa-solid fa-user"></i> Bejelentkezés</a>
          </li>
        <?php endif; ?>
      </ul>

    </div>
  </div>
</nav>
<div class="container mt-4">

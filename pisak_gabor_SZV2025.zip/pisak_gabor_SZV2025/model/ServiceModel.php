<?php
require_once 'Database.php';

class ServiceModel {
    private $pdo;

    public function __construct()
    {
        // Beállítjuk a PDO kapcsolatot
        $dsn = 'mysql:host=localhost;dbname=pisak_gabor_szv2025;charset=utf8';
        $user = 'root';
        $password = '';

        try {
            $this->pdo = new PDO($dsn, $user, $password);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Adatbázis kapcsolat hiba: " . $e->getMessage());
        }
    }

    public function getServicesByEmail($email)
    {
        $sql = "SELECT t.id, t.szeriaszam, t.gyarto, t.tipus, t.statusz, t.statusz_valtozas, t.leadas_datum
                FROM termekek t
                INNER JOIN kapcsolattartok k ON t.id = k.termek_id
                WHERE k.email = ?";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$email]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getActiveServices() {
        $conn = Database::getConnection();
        $today = date('Y-m-d');
        $query = "SELECT * FROM termekek 
                  WHERE statusz != 'Kész' 
                  OR (statusz = 'Kész' AND DATE(statusz_valtozas) = ?)
                  ORDER BY FIELD(statusz, 'Beérkezett', 'Hibafeltárás', 'Alkatrész beszerzés alatt', 'Javítás', 'Kész')";

        $stmt = $conn->prepare($query);
        $stmt->bind_param('s', $today);
        $stmt->execute();
        return $stmt->get_result();
    }

    public function addService($data) {
        $conn = Database::getConnection();
        $query1 = "INSERT INTO termekek (szeriaszam, gyarto, tipus, leadas_datum, statusz, statusz_valtozas)
                   VALUES (?, ?, ?, CURDATE(), 'Beérkezett', CURDATE())";

        $stmt1 = $conn->prepare($query1);
        $stmt1->bind_param('sss', $data['szeriaszam'], $data['gyarto'], $data['tipus']);
        $stmt1->execute();
        $termek_id = $stmt1->insert_id;

        $query2 = "INSERT INTO kapcsolattartok (termek_id, nev, telefon, email) VALUES (?, ?, ?, ?)";
        $stmt2 = $conn->prepare($query2);
        $stmt2->bind_param('isss', $termek_id, $data['nev'], $data['telefon'], $data['email']);
        $stmt2->execute();
    }
}

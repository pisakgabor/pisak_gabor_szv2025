<?php
require_once 'controller/ServiceController.php';

$controller = new ServiceController();
$page = $_GET['page'] ?? 'home';

if ($page === 'add') {
    $controller->showAddForm();
} elseif ($page === 'mod') {
    $controller->showStatuszModPage();
} elseif ($page === 'home') {
    $controller->showHomePage();
} elseif ($page === 'check') {
    $controller->showCheckPage();
} else {
    $controller->showList();
}
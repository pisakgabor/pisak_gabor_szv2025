<?php
class Database {
    private static $conn;

    public static function getConnection() {
        if (!self::$conn) {
            self::$conn = new mysqli('localhost', 'root', '', 'pisak_gabor_szv2025');
            if (self::$conn->connect_error) {
                die("Kapcsolódási hiba: " . self::$conn->connect_error);
            }
        }
        return self::$conn;
    }
}

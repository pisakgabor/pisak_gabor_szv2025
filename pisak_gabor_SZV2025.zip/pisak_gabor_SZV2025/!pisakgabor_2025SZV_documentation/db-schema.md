# Adatbázis Séma Dokumentáció

### kapcsolattartok

| Oszlop | Típus | Null? | Kulcs |
|--------|-------|-------|-------|
| id | int(11) | NO | PRI |
| termek_id | int(11) | NO | MUL |
| nev | varchar(100) | NO |  |
| telefon | varchar(30) | NO |  |
| email | varchar(100) | NO |  |

### termekek

| Oszlop | Típus | Null? | Kulcs |
|--------|-------|-------|-------|
| id | int(11) | NO | PRI |
| szeriaszam | varchar(100) | NO |  |
| gyarto | varchar(100) | NO |  |
| tipus | varchar(100) | NO |  |
| leadas_datum | date | NO |  |
| statusz | enum('Beérkezett','Hibafeltárás','Alkatrész beszerzés alatt','Javítás','Kész') | NO |  |
| statusz_valtozas | datetime | NO |  |

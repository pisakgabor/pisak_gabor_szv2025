<?php
require_once 'helper/Auth.php';

logout();
header('Location: index.php');
exit;

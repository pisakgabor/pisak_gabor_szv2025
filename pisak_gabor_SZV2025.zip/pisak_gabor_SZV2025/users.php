<?php
return [
    'szervizes' => 'szerviz01234',
];

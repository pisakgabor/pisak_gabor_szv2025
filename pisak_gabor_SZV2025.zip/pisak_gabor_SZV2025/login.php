<?php
require_once 'helper/Auth.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = $_POST['username'] ?? '';
    $pass = $_POST['password'] ?? '';

    if (login($user, $pass)) {
        header("Location: index.php");
        exit;
    } else {
        $error = 'Hibás bejelentkezési adatok!';
    }
}
?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Belépés </title>
  <link rel='stylesheet' href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css'>
<link rel='stylesheet' href='https://fonts.googleapis.com/css2?family=Poppins&amp;display=swap'>
<link rel="stylesheet" href="public/css/style_login.css">

</head>
<body>

<div class="container mt-5">    

<?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
<div class="wrapper">
  <div class="login_box">
    <div class="login-header">
      <span>Belépés</span>
    </div>
Kisgép szervíz 
 <form method="post">
    <div class="input_box">
      <input type="text" id="username" name="username" class="input-field" required>
      <label for="username" class="label">Felhasználó</label>
      <i class="bx bx-user icon"></i>
    </div>

    <div class="input_box">
      <input type="password" id="password" name="password"class="input-field" required>
      <label for="password" class="label">Jelszó</label>
      <i class="bx bx-lock-alt icon"></i>
    </div>
	
	<hr>
	
    <div class="input_box">
	<button type="submit" class="input-submit">Bejelentkezés</button>
 
    </div>
</form>
    <div class="register">
      <span>A bejelentkezés csak a kisgépszervíz munkatársai részére elérhető!</span>
      <br><hr><br>
    </div>
  </div>
</div>
<!-- partial -->

</div>
<div class="container mt-5">
    <h2>Bejelentkezés</h2>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="post">
        <div class="mb-3">
            <label for="username">Felhasználónév:</label>
            <input type="text" name="username" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="password">Jelszó:</label>
            <input type="password" name="password" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Bejelentkezés</button>
    </form>
</div>
<?php include 'view/footer.php'; ?>
